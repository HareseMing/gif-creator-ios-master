gif-creator-ios
===============

iOS Application for create animated gif with the library photos
