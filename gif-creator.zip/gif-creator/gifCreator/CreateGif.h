//
//  CreateGif.h
//  gifCreator
//
//  Created by remi on 21/04/14.
//  Copyright (c) 2014 remi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CreateGif : NSObject

+ (void) makeAnimatedGif:(NSArray *)tabImage :(UIViewController *)vc;
//+ (void) makeAnimatedGif:(NSArray *)tabImage;

@end
