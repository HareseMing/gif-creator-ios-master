//
//  FUNeedSwitch.h
//  gifCreator
//
//  Created by Ntgod on 2019/2/15.
//  Copyright © 2019年 remi. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FUNeedSwitch : NSObject

@property(nonatomic, strong, readwrite) UIColor *fuBackgroundColor ;
@property(nonatomic, strong, readwrite) UIColor *faBackgroundColor ;
@property(nonatomic, strong, readwrite) UIColor *fuColor ;


@end

NS_ASSUME_NONNULL_END
