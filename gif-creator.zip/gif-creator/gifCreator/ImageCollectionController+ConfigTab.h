//
//  ImageCollectionController+ConfigTab.h
//  gifCreator
//
//  Created by remi on 10/04/14.
//  Copyright (c) 2014 remi. All rights reserved.
//

#import "ImageCollectionController.h"

@interface ImageCollectionController (ConfigTab)

- (void) initconfigBar;
- (void) alertReset;

@end
